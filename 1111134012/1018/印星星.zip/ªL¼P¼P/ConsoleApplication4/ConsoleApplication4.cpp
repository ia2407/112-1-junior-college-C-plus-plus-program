﻿
#include <iostream>
#include <stdio.h>
int main()
{
	int i, d;
	for (i = 1; i <= 10; i++) {
		for (d = 1; d <= i; d++) {
			printf("*");
		}
		printf("\n");
	}
	int a, b;
	for (a = 1; a <= 10; a++) {
		for (b = a;b <= 10; b++) {
			printf("*");
		}
		printf("\n");
	}
	int f, g,h;
	for (f = 1; f <= 10; f++) {
		for (g = 1; g <= 10-f; g++) {
			printf(" ");
		}
		for (h = 1; h <= f ; h++) {
			printf("*");
		}
		printf("\n");
	}
	int q, w, e;
	for (q = 0; q <= 10; q++) {
		for (w = 1; w <= q ; w++) {
			printf(" ");
		}
		for (e = 1; e <= 10-q; e++) {
			printf("*");
		}
		printf("\n");
	}
}

